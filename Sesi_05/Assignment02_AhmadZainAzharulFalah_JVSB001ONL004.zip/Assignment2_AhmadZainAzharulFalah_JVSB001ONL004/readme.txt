Nama                        : Ahmad Zain Azharul Falah
Kode Peserta                : JVSB001ONL004
Link Github                 : 
Panduan Penggunaan Aplikasi :

1. Latihan01.java
    - Mendeklarasikan variabel dan scanner yang dibutuhkan
    - Membuat program input data yang dibutuhkan pada array
    - Membuat kode untuk menghitung rata-rata dari semua data pada array
    - Membuat kode untuk mendapatkan nilai terbesar dan terkecil pada array
    - Mencetak hasil dari program

2. Latihan02.java
    - Mendeklarasikan array multidimensi
    - Mengisi nilai pada array tersebut sesuai kebutuhan program
    - Mencetak hasil yang dibutuhkan untuk program

3. Latihan03.java
    - Mendeklarasikan variabel dan scanner
    - Membuat kode program untuk mengambil input
    - Membuat proses kondisi untuk proses sesuai kebutuhan program
    - Mencetak hasil dari program

4. Latihan04.java
    - Mendeklarasikan variabel dan scanner
    - Membuat kode program untuk proses input data pada variabel
    - Membuat kode program kondisi untuk mendapatkan hasil yang dibutuhkan dari program
    - Mencetak hasil dari program tersebut

5. Latihan05.java
    - Import beberapa class yang dibutuhkan
    - Mendeklarasikan scanner, variabel, dan array
    - Menulis program switch case untuk memasukkan elemen di dalam array
    - Menulis kode program pengaturan format number
    - Menulis kode program untuk menampilkan seluruh elemen di dalam array
    - Menampilkan total bayar