Nama         : Ahmad Zain Azharul Falah
Kode Peserta : JVSB001ONL004
Link Github  : https://github.com/zenzett/Hacktiv8-JavaSpringBoot

Panduan Penggunaan Aplikasi :
	1. pom.xml > update maven project > clean > install
	2. klik folder > run as spring boot app