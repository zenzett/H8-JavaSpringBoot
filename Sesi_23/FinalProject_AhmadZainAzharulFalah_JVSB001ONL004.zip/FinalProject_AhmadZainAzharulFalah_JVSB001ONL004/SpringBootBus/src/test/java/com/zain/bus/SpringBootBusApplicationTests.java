package com.zain.bus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBusApplicationTests {

	@Test
	void contextLoads() {
	}

}
