INSERT INTO `bus`(`capacity`, `code`, `make`, `agency_id`)
VALUES (20,"BDL01","20",1);

INSERT INTO `bus`(`capacity`, `code`, `make`, `agency_id`)
VALUES (15,"BDL02","15",1);