public class LuasLingkaran {
    public static void main(String[] args) {
        
        double luas, p1 = 3.14;
        int r = 18;

        luas = p1 * r * r;
        System.out.println("Luas lingkaran adalah " + luas);
    }
}
