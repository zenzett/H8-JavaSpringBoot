Nama                        : Ahmad Zain Azharul Falah
Kode Peserta                : JVSB001ONL004
Link Github                 : 
Panduan Penggunaan Aplikasi :

1. 	LuasLingkaran.java
	- Memdeklarasikan variabel untuk menghitung luas lingkaran
	- Memasukkan nilai untuk masing-masing variabel tersebut.
	- Membuat proses penghitungan luas lingkaran.
	- Mencetak hasil perhitungan luas lingkaran.

2. 	Aritmatika.java
	- Membuat variabel dan memasukkan nilainya.
	- Membuat proses perhitungan aritmatika sesuai yang telah ditentukan.
	- Mencetak hasil dari semua perhitungan tersebut.

3.	IncrementDecrement.java
	- Membuat variabel dan menginput nilainya.
	- Mencetak beberapa proses sesuai dengan yang telah ditentukan.
	- Membuat kode program untuk mencetak hasil sesuai dengan output yang telah ditentukan.

4.	PerbandinganTrueFalse.java
	- Membuat variabel awal dan memasukkan nilainya.
	- Membuat kode program untuk menghasilkan output seperti yang telah ditentukan.
	- Mencetak hasil dari proses tersebut.

5	a. PenjumlahanXY.java
	- Mendeklarasikan variabel awal sesuai dengan yang telah ditentukan.
	- Mencetak hasil dari variabel tersebut untuk mengetahui hasilnya.

	b. LanjutanPenjumlahan.java
	- Membuat variabel baru untuk mencetak hasil sesuai output yang telah ditentukan.
	- Membuat kode program untuk menghasilkan output sesuai dengan yang telah ditentukan.