public class PenjumlahanXY {
    public static void main(String[] args) {
        int y1 = 7, y2 = 2;
        int z = ( y1 + y2 );
        //int jmlx1 = (y1 + y2);

        int x1 = (y1 + y2) * z;
        int x2 = (y1 % 4) * y2;

        System.out.println(x1);
        System.out.println(x2);

    }
}
